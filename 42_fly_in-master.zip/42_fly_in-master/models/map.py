from __future__ import annotations
from error import ErrorFlyIn
from typing import List
from models.hub import Hub


# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█▄█░█▀█░█▀█
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█░█░█▀█░█▀▀
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▀░▀░▀░▀░▀░░
class Map:
    def __init__(self, name: str = "No name") -> None:
        self._name: str = name
        self._nb_drones: int = 0
        self._hubs: List[Hub] = []

    # ########################################################################
    # ############################################################## HUBS ####

    # ############################################### START / STOP ####
    # TODO: CHANGE TO ATTRIBUTES ?
    @property
    def start(self) -> Hub | None:
        return next(h for h in self._hubs if h.type == Hub.Type.START)

    @property
    def end(self) -> Hub | None:
        return next(h for h in self._hubs if h.type == Hub.Type.END)

    @property
    def hubs(self) -> List[Hub]:
        return self._hubs

    # ######################################################### += ####
    def __iadd__(self, hub: Hub) -> Map:
        """
        Add the hub inside the map

        Raise ErrorMap if name or point already exist in the map
        """
        if any(h.name == hub.name for h in self._hubs):
            raise ErrorMap(f"{hub.name} already exists in the map.")

        if any(h.point == hub.point for h in self._hubs):
            raise ErrorMap(f"There is already a hub at {hub.point}.")

        if hub.type != Hub.Type.REGULAR and any(
            h.type == hub.type for h in self._hubs
        ):
            raise ErrorMap(f"There is already a {hub.type} in the map.")

        self._hubs.append(hub)
        return self

    # #################################################### CONNECT ####
    def connect_hubs(self, from_name: str, to_name: str) -> None:
        """
        Add 'to' to 'from'

        Raise ErrorMap to or from hubs are not found in the hub list
        """
        hub_from = next((h for h in self._hubs if h.name == from_name), None)
        hub_to = next((h for h in self._hubs if h.name == to_name), None)

        if not hub_from:
            raise ErrorMap(f"{from_name} doesn't exist in the map.")
        if not hub_to:
            raise ErrorMap(f"{to_name} doesn't exist in the map.")

        hub_from += hub_to

    # ########################################################################
    # ######################################################### NB DRONES ####
    @property
    def nb_drones(self) -> int:
        return self._nb_drones

    @nb_drones.setter
    def nb_drones(self, nb: int) -> None:
        if nb < 1:
            raise ErrorMap("Nb drones cannot be less than 1")

        self._nb_drones = nb

    # ########################################################################
    # ############################################################# VALID ####
    @property
    def is_valid(self) -> bool:
        """
        Perform tests and raise an ErrorMap on any invalid one
        Return True
        """

        if self._nb_drones < 2:
            raise ErrorMap("Map needs at least two drones")

        if not any(h.point == Hub.Type.START for h in self._hubs):
            raise ErrorMap("Map needs at least one starting hub")

        if not any(h.point == Hub.Type.END for h in self._hubs):
            raise ErrorMap("Map needs at least one ending hub")

        if not any(h.point == Hub.Type.REGULAR for h in self._hubs):
            raise ErrorMap("Map needs at least one REGULAR hub")

        return True

    # TODO: TEST THE GRAP LOGIC - ARE ALL HUBS CONNECTED ??
    def test_hubs(self) -> bool:

        return True

    # ########################################################################
    # ############################################################### STR ####
    def __str__(self) -> str:
        return (
            f"Map: {self._name}\n"
            f"Nb drones: {self.nb_drones}\n"
            f"Hubs ({len(self._hubs)}):\n"
            f"{'\n'.join((str(h) for h in self._hubs))}"
        )


# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█▀▀░█▀▄░█▀▄░█▀█░█▀▄
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█▀▀░█▀▄░█▀▄░█░█░█▀▄
# ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▀▀▀░▀░▀░▀░▀░▀▀▀░▀░▀
class ErrorMap(ErrorFlyIn):
    def __init__(self, message: str) -> None:
        super().__init__(f"Map error:\n{message}")
